from django.apps import AppConfig


class ScrollingConfig(AppConfig):
    name = 'scrolling'
