from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.views.decorators.csrf import csrf_exempt
from rest_framework.utils import json


# Create your views here.

def test(request):
    ctx = {}
    obj = PostImage.objects.all()
    if obj:
        ctx["images"] = obj

    return render(request, "scrolling/infinite_scrolling.html", ctx)


@csrf_exempt
def test_data(request):
    ctx = {}
    data_dict = {}
    path_list=[]
    s = 0
    e = 0
    if request.method == "POST":
        index = request.POST['index']
        if index:
            s = int(index)

    e = s + 6
    obj = PostImage.objects.all()[s:e]
    if obj:
        for path in obj:
            print("",path.images)
            # data_dict={
            #     "path":str(path.images)
            # }
            path_list.append(str(path.images))

    ctx['data'] = path_list
    ctx['new_index'] = e
    return HttpResponse(json.dumps(ctx))
