from django.contrib import admin
from django.urls import include, path

from .views import *
urlpatterns = [
path("test/",test),
path("test_data/",test_data),
]